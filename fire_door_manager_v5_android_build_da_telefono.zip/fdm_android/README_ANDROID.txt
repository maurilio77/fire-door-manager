FIRE DOOR MANAGER V5 - PROGETTO APP ANDROID

Questa cartella contiene il progetto Android Studio che incorpora la versione offline V5
in una WebView a schermo intero: l'app si apre dalla propria icona e non mostra la barra
del browser. Non richiede connessione Internet per usare il gestionale.

Per generare l'APK:
1. Installa Android Studio su un PC.
2. Estrai questo ZIP.
3. In Android Studio scegli "Open" e seleziona la cartella FireDoorManager.
4. Attendi la sincronizzazione Gradle e l'installazione dei componenti Android richiesti.
5. Seleziona Build > Build Bundle(s) / APK(s) > Build APK(s).
6. L'APK di prova si trova in app/build/outputs/apk/debug/app-debug.apk.
7. Copia l'APK sul telefono Android e aprilo per installarlo. Potrebbe essere necessario
   autorizzare temporaneamente l'installazione da questa origine nelle impostazioni Android.

NOTE IMPORTANTI:
- Questa consegna è il progetto sorgente pronto per Android Studio, non un APK già compilato.
- L'ambiente di preparazione non dispone dell'SDK Android/Gradle necessario per compilare e
  firmare direttamente il file APK.
- I dati restano nella memoria locale dell'app. Non disinstallare l'app o cancellarne i dati
  senza prima esportare il backup JSON.
- Per trasferire i dati dalla versione browser: esporta il backup JSON dalla V5 precedente.
  La prima importazione va eseguita dall'app dopo l'installazione.
- La stampa dei verbali usa il servizio di stampa Android, da cui scegliere "Salva come PDF".
- Foto e selezione file sono abilitate tramite il selettore Android.
